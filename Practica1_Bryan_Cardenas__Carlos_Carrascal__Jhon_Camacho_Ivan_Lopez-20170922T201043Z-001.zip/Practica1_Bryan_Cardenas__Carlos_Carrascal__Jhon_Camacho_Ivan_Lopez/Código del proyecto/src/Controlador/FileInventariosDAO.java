/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

/**
 *
 * @author carloscarrascal
 */


import Modelo.Inventarios;
import static java.nio.file.StandardOpenOption.APPEND;


import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.SeekableByteChannel;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




public abstract class FileInventariosDAO implements InventariosDAO {

	
	private static final String NOMBRE_ARCHIVO = "Inventarios";
	private static final Path file= Paths.get(NOMBRE_ARCHIVO);
	private static final int LONGITUD_REGISTRO = 60;
	private static final int ID_PRODUCTO_LONGITUD = 20;
	private static final int CODIGO_ALMACEN_LONGITUD = 20;
        private static final int CANTIDAD_LONGITUD = 20;
	
	
	
	private static final Map<String, Inventarios> CACHE_INVENTARIOS = new HashMap<String, Inventarios>();
	
//Método para registrar cantidades del inven
	@Override
	public boolean saveInventarios(Inventarios inventarios) {
		
		String registro=parseTipoProductoString(inventarios);

		byte data[] = registro.getBytes();
		ByteBuffer out = ByteBuffer.wrap(data);	
		try (FileChannel fc = (FileChannel.open(file, APPEND))) {
			fc.write(out);
			return true;
		} catch (IOException x) {
			System.out.println("I/O Exception: " + x);
		}
		return false;
	}
	

	//Método para listar los inventarios 
	@Override
	public List<Inventarios> getAllInventarios() {	
		List<Inventarios> inventarios= new ArrayList<Inventarios>();
		try (SeekableByteChannel sbc = Files.newByteChannel(file)) {
		    ByteBuffer buf = ByteBuffer.allocate(LONGITUD_REGISTRO);  
		    
		    // Se utiliza la propiedad del sistema que indica la codificaci�n de los archivos 
		    String encoding = System.getProperty("file.encoding");
		    while (sbc.read(buf) > 0) {
		        buf.rewind();
		        Inventarios inventario = parseTipoInventarios(Charset.forName(encoding).decode(buf));
		        buf.flip();
		        inventarios.add(inventario);		        
		    }
		} catch (IOException x) {
		    System.out.println("caught exception: " + x);
		}
		return inventarios;
	}
		


	//Método para convertir CharBuffer a objeto inventario
	private Inventarios parseTipoInventarios(CharBuffer registro){		
		String id_producto = registro.subSequence(0, ID_PRODUCTO_LONGITUD ).toString();
		registro.position(ID_PRODUCTO_LONGITUD);
		registro=registro.slice();
				
		String cod_almacen = registro.subSequence(0, CODIGO_ALMACEN_LONGITUD).toString();
		registro.position(CODIGO_ALMACEN_LONGITUD);	
		registro=registro.slice();
                
                String cantidad = registro.subSequence(0, CANTIDAD_LONGITUD).toString();
		registro.position(CANTIDAD_LONGITUD);	
		registro=registro.slice();
		
				
		
		Inventarios i=new Inventarios(cantidad, id_producto, cod_almacen);
		return i;
	}
	
	private String parseTipoProductoString(Inventarios inventario){
		StringBuilder registro = new StringBuilder(LONGITUD_REGISTRO);
		registro.append(completarCampoConEspacios(inventario.getId_producto(),ID_PRODUCTO_LONGITUD));
		registro.append(completarCampoConEspacios(inventario.getCodigo_almacen(), CODIGO_ALMACEN_LONGITUD));
                registro.append(completarCampoConEspacios(inventario.getCantidad(), CANTIDAD_LONGITUD));
			
		return registro.toString();
	}
	
	/**
	 * Rellena con espacios a la derecha el String que se env�e como par�metro. Si el tama�o del String
	 * supera el valor del tama�o que se env�a como par�metro, se ajusta el contenido del String a dicho tama�o
	 * @param campo, tamanio
	 * @return String
	 */
	private String completarCampoConEspacios(String campo, int tamanio){
		if(campo.length()>tamanio){//Ser responsable y lanzar una excepci�n
			campo=campo.substring(0, tamanio);
			return campo;
		}
		return String.format("%1$-" + tamanio + "s", campo);
	}


}
/**
 *
 * @author carloscarrascal
 */
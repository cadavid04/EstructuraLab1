/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author carloscarrascal
 */
public class Detalle_ventas {
    
    
    int cantidad;
    private Ventas consecutivo_venta;
    private Productos id_producto;
}
